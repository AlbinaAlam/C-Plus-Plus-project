#include <iostream>
#include <bits/stdc++.h>
#include <string.h>
#include <fstream>
#include "admin.h"
#include "Modifier.h"
#include "user.h"
#include "Patient.h"
#include "Doctor.h"
#include <bits/stdc++.h>
using namespace std;

#define limit 30
void menu (int c);
Modifier m1;
//Modifier m1;
user u1;
Modifier m;
int main()
{
    //cout << "Hello world!" << endl;
   // Patient p[MAX];

Modifier m1;
//Modifier m1;
user u1;
Modifier m;
//admin a;

    //int room[MAX]= {301,302,303};
    int c,i;
    char aa[limit];
    admin a1;
    while(1)
    {
    cout<<"are you user or clinic administration?"<<endl;
    cout<<"select your option"<<endl;

        cout<<" 1. USER.  2.clinic administration. "<<endl;
        cin>>i;
        if(i==1)
        {
            char a;
        m.wel_msg_d();
        m. searching();
        cout<<"do you want to make a serial :";
        cout<<"(y/n)"<<"enter your choice"<<endl;
        cin>>a;

        if(a=='y')
        {
            u1.wel_msg_p();
            int r=u1.Pat_info();


        }
        else
        {
            exit(0);
        }


        }
        else
        {
            cout<<"are you user or doctor or admin?"<<endl;
        cout<<"select your option"<<endl;

        cout<<" 1. USER.  2.DOCTOR.  3.ADMIN  4.Patient"<<endl;
        cin>>c;
        menu(c);
        u1.saveAll();
        m.savedAll();cout<<"are you user or doctor or admin?"<<endl;
        cout<<"select your option"<<endl;

        cout<<" 1. USER.  2.DOCTOR.  3.ADMIN  4.Patient"<<endl;
        cin>>c;
        menu(c);
        u1.saveAll();
        m.savedAll();
        }




    }



    return 0;
}
void menu (int c)
{
    Modifier m1;
//Modifier m1;
user u1;
Modifier m;
admin a1;
    int i;

    if(c==1)
    {
menuoption:
        cout<<"enter password:"<<endl;
        cin>>i;
        if(i==a1.setpassu())
        {
            cout<<"Successfully loged in as user"<<endl;
            u1.wel_msg_p();
            u1.task();


        }
        else
        {
            cout<<"wrong password"<<endl<<"please try again"<<endl;
            goto menuoption;
        }

    }

    else if(c==20)
    {
password:
        cout<<"enter password:"<<endl;
        cin>>i;
        if(i==a1.setpassd())
        {
            cout<<"Successfully loged in as user"<<endl;

            m.wel_msg_d();
            m.editor();


        }
        else
        {
            cout<<"wrong password"<<endl<<"please try again"<<endl;
            goto password;
        }
    }
    else if(c==3)
    {
        a1.show();
    }
    else if(c==4)
    {


    }
    else
    {
        exit(0);
    }


}
